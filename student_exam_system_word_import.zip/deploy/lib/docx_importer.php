<?php
declare(strict_types=1);

function docx_paragraphs(string $path): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('افزونه ZipArchive در PHP فعال نیست.');
    }
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        throw new RuntimeException('فایل DOCX قابل خواندن نیست.');
    }
    $xml = $zip->getFromName('word/document.xml');
    $zip->close();
    if ($xml === false) {
        throw new RuntimeException('ساختار فایل DOCX معتبر نیست.');
    }
    $dom = new DOMDocument();
    $dom->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    $xpath = new DOMXPath($dom);
    $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $result = [];
    foreach ($xpath->query('//w:body/w:p') as $p) {
        $parts = [];
        foreach ($xpath->query('.//w:t', $p) as $textNode) {
            $parts[] = $textNode->nodeValue;
        }
        $result[] = trim(implode('', $parts));
    }
    return $result;
}

function parse_question_docx(string $path): array
{
    $lines = docx_paragraphs($path);
    $questions = [];
    $errors = [];
    $block = null;
    $lineNo = 0;
    foreach ($lines as $line) {
        $lineNo++;
        $line = trim(preg_replace('/\x{FEFF}/u', '', $line));
        if ($line === '') continue;
        $upper = strtoupper($line);
        if ($upper === 'QUESTION') {
            if ($block !== null) $errors[] = "خط {$lineNo}: بلوک قبلی با END بسته نشده است.";
            $block = ['type'=>'MCQ','score'=>1,'text'=>'','options'=>['A'=>'','B'=>'','C'=>'','D'=>''],'answer'=>'','feedback'=>''];
            continue;
        }
        if ($upper === 'END') {
            if ($block === null) { $errors[] = "خط {$lineNo}: END بدون QUESTION."; continue; }
            $block['_line'] = $lineNo;
            $questions[] = $block;
            $block = null;
            continue;
        }
        if ($block === null) continue;
        if (!str_contains($line, ':')) { $errors[] = "خط {$lineNo}: قالب باید KEY: VALUE باشد."; continue; }
        [$key, $value] = array_map('trim', explode(':', $line, 2));
        $key = strtoupper($key);
        if ($key === 'TYPE') $block['type'] = strtoupper($value);
        elseif ($key === 'SCORE') $block['score'] = (float)$value;
        elseif ($key === 'TEXT') $block['text'] = $value;
        elseif (in_array($key, ['A','B','C','D'], true)) $block['options'][$key] = $value;
        elseif ($key === 'ANSWER') $block['answer'] = strtoupper($value);
        elseif ($key === 'FEEDBACK') $block['feedback'] = $value;
        else $errors[] = "خط {$lineNo}: کلید ناشناختهٔ {$key}.";
    }
    if ($block !== null) $errors[] = 'آخرین بلوک با END بسته نشده است.';
    foreach ($questions as $i => $q) {
        $n = $i + 1;
        if ($q['text'] === '') $errors[] = "پرسش {$n}: TEXT خالی است.";
        if ($q['score'] <= 0) $errors[] = "پرسش {$n}: SCORE باید بزرگ‌تر از صفر باشد.";
        if (!in_array($q['type'], ['MCQ','TRUE_FALSE','SHORT'], true)) $errors[] = "پرسش {$n}: TYPE نامعتبر است.";
        if ($q['type'] === 'MCQ') {
            foreach (['A','B','C','D'] as $key) if ($q['options'][$key] === '') $errors[] = "پرسش {$n}: گزینهٔ {$key} خالی است.";
            if (!in_array($q['answer'], ['A','B','C','D'], true)) $errors[] = "پرسش {$n}: ANSWER باید یکی از A، B، C یا D باشد.";
        } elseif ($q['type'] === 'TRUE_FALSE') {
            if (!in_array($q['answer'], ['A','B'], true)) $errors[] = "پرسش {$n}: ANSWER برای TRUE_FALSE باید A یا B باشد.";
        }
    }
    return [$questions, $errors];
}
