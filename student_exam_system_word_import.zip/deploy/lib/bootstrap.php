<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';
date_default_timezone_set($config['app']['timezone'] ?? 'Asia/Tehran');

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
session_name($config['app']['session_name'] ?? 'student_exam_session');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    global $config;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', $config['db']['host'], $config['db']['name'], $config['db']['charset']);
    $pdo = new PDO($dsn, $config['db']['user'], $config['db']['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = ''): string { global $config; return rtrim($config['app']['base_url'], '/') . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path))); exit; }
function flash(string $key, ?string $value = null): ?string { if ($value !== null) { $_SESSION['_flash'][$key] = $value; return null; } $v = $_SESSION['_flash'][$key] ?? null; unset($_SESSION['_flash'][$key]); return $v; }
function csrf_token(): string { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { if (!hash_equals($_SESSION['_csrf'] ?? '', $_POST['csrf_token'] ?? '')) { http_response_code(419); exit('درخواست نامعتبر است. صفحه را تازه‌سازی کنید.'); } }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function login_user(array $user): void { session_regenerate_id(true); $_SESSION['user'] = ['id'=>(int)$user['id'], 'role'=>$user['role'], 'full_name'=>$user['full_name'], 'mobile'=>$user['mobile']]; }
function logout_user(): void { $_SESSION = []; if (ini_get('session.use_cookies')) { $p = session_get_cookie_params(); setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']); } session_destroy(); }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function require_role(string ...$roles): void { require_login(); if (!in_array(current_user()['role'], $roles, true)) { http_response_code(403); exit('شما مجوز دسترسی به این بخش را ندارید.'); } }
function audit(string $action, ?string $entityType = null, ?int $entityId = null): void { $u = current_user(); $stmt = db()->prepare('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address) VALUES (?, ?, ?, ?, ?)'); $stmt->execute([$u['id'] ?? null, $action, $entityType, $entityId, $_SERVER['REMOTE_ADDR'] ?? null]); }
function post_string(string $key, int $max = 10000): string { return mb_substr(trim((string)($_POST[$key] ?? '')), 0, $max); }
function get_int(string $key): int { return max(0, (int)($_GET[$key] ?? 0)); }
function format_score($score): string { return number_format((float)$score, 2, '.', ''); }
